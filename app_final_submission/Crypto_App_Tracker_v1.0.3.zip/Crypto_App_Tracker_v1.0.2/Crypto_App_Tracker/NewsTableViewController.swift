//
//  NewsTableViewController.swift
//  Crypto_App_Tracker
//
//  Created by student on 10/23/21.
//

import UIKit

struct NewsData: Codable {
    init () {
        data = [News]()
    }
    let data: [News]
}

struct News: Codable {
    init() {
        news_url = ""       //Get a default
        image_url = ""      //Get a default
        title = ""
        text = ""
        source_name = ""
        date = ""
        topics = []
        sentiment = ""
        type = ""
    }
    let news_url: String
    let image_url: String
    let title: String
    let text: String        //1st part of news or description
    let source_name: String //Made By: source_name
    let date: String        //Format: "DayOfWeek, Day# Month Year HH(0-23):MM:SS -4000"
    let topics: [String]    //Can be empty, not of much use
    let sentiment: String   //"Neutral", "Positive", or "Negative"
    let type: String        //"Article" or "Video", may want option to see one or the other
}

class NewsTableViewController: UITableViewController {
    var newsInfo = [News]()
    var selectedNews = News()
    var coinInfo: [ViewController.JSONPrice] = []   //Just for images/logos of coins
    var coinList = ["bitcoin","ethereum"]           //Default
    //Add a dictionary of all coins and their abbreviations

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let newsUrl = URL(string: "https://cryptonews-api.com/api/v1/category?section=general&items=50&sortby=rank&days=7&token=cpczksgr2munv2mmwhyfckriud19t6k01cxmb1so")
        if newsUrl != nil {
            parseData(url: newsUrl!)
        }
        
        runCoinAPI(url: makeCoinAPIList(&coinList))
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsInfo.count
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 165
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let cell_CoinName = cell.viewWithTag(1) as! UILabel
        cell_CoinName.text = "General"  //Default
        
        let cell_CoinImage = cell.viewWithTag(2) as! UIImageView
        cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")       //Default (for General)
//        if let c_i = coinList.firstIndex(of: "bitcoin") { //Replace "bitcoin" -> dictionary of ticker(s) [abbreviations of coin(s)] when getting news of those coin(s)
//            if let url = URL(string: self.coinInfo[c_i].image) {
//                URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
//                    if error != nil {
//                        print(error!.localizedDescription)
//                        return
//                    }
//                    DispatchQueue.main.async {
//                        cell_CoinImage.image = UIImage(data: data!)
//                    }
//                }).resume()
//            }
//        } else {
//            cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")       //Default (for General)
//        }
        
        let cell_NewsImage = cell.viewWithTag(3) as! UIImageView
        if let url = URL(string: self.newsInfo[indexPath.row].image_url) {
            URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error!.localizedDescription)
                    return
                }
                DispatchQueue.main.async {
                    cell_NewsImage.image = UIImage(data: data!)
                }
            }).resume()
        }
        
        let cell_Date_By = cell.viewWithTag(4) as! UILabel
        let newsDate = self.newsInfo[indexPath.row].date.components(separatedBy: " ")
        var newsDateShort = ""
        switch newsDate[2] {
        case "Jan":
            newsDateShort += "1/"
        case "Feb":
            newsDateShort += "2/"
        case "Mar":
            newsDateShort += "3/"
        case "Apr":
            newsDateShort += "4/"
        case "May":
            newsDateShort += "5/"
        case "Jun":
            newsDateShort += "6/"
        case "Jul":
            newsDateShort += "7/"
        case "Aug":
            newsDateShort += "8/"
        case "Sep":
            newsDateShort += "9/"
        case "Oct":
            newsDateShort += "10/"
        case "Nov":
            newsDateShort += "11/"
        case "Dec":
            newsDateShort += "12/"
        default:
            newsDateShort += "00/"
        }
        newsDateShort += "\(newsDate[1])/\(newsDate[3])"
        cell_Date_By.text = "\(newsDateShort) | By: \(self.newsInfo[indexPath.row].source_name)"
        
        let cell_Title = cell.viewWithTag(5) as! UILabel
        cell_Title.text = self.newsInfo[indexPath.row].title
        
        let cell_Text = cell.viewWithTag(6) as! UILabel
        cell_Text.text = self.newsInfo[indexPath.row].text
        
        let cell_Sentiment = cell.viewWithTag(7) as! UILabel
        cell_Sentiment.text = self.newsInfo[indexPath.row].sentiment
        var sentimentColor: UIColor
        switch self.newsInfo[indexPath.row].sentiment {
            case "Positive":
                sentimentColor = #colorLiteral(red: 0.2509803922, green: 0.7490196078, blue: 0.4666666667, alpha: 1)
            case "Negative":
                sentimentColor = #colorLiteral(red: 0.8980392157, green: 0.2745098039, blue: 0.1411764706, alpha: 1)
            default:
                sentimentColor = #colorLiteral(red: 0.3254901961, green: 0.3803921569, blue: 0.3843137255, alpha: 1)
        }
        cell_Sentiment.textColor = sentimentColor
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seg_news_page" {
            let mapView = segue.destination as! NewsViewController
            mapView.selectedNewsUrl = selectedNews.news_url
        }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedNews = newsInfo[indexPath.row]
        self.performSegue(withIdentifier: "seg_news_page", sender: self)
    }

    func parseData(url: URL) {
        let task = URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
            if let d = data {
                self.decodeData(downloadedData: d)
            }
            else if let e = error {
                print(e.localizedDescription)
            }
        })
        task.resume()
    }
    func decodeData(downloadedData: Data) {
        do {
            let content = try JSONDecoder().decode(NewsData.self, from: downloadedData)
            self.newsInfo = content.data
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        } catch {
            print("Error while decoding JSON data")
        }
    }
    
    func makeCoinAPIList(_ localArr: inout [String]) -> String {
        if (localArr.count > 0 ){
            var temp = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
            for i in localArr {
                temp.self += "\(i),"
            }
            return temp
        } else { return "" }
    }
    func runCoinAPI(url: String) {
        coinInfo.removeAll()
        guard let url = URL(string: url) else { return }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let dataResponse = data,
                  error == nil else {
                print(error?.localizedDescription ?? "Response Error")
                return }
            do {
                let decoder = JSONDecoder()
                let model = try decoder.decode([ViewController.JSONPrice].self, from: dataResponse)
                //print(model)
                self.coinInfo = model
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch let parsingError {
                print("Error", parsingError)
            }
        }.resume()
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
