//
//  AddCoinViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 10/4/21.
//

import UIKit

class AddCoinViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    var curList = [""]
    
    var addList = ["bitcoin","ethereum","cardano","binancecoin","ripple","solana","dogecoin","polkadot","terra-luna","avalanche-2","uniswap","chainlink","litecoin","algorand","bitcoin-cash","shiba-inu","cosmos","internet-computer","matic-network","filecoin","axie-infinity","stellar","vechain","ethereum-classic","ftx-token","tron","tezos","theta-token","monero","elrond-erd-2","crypto-com-chain","okb","eos","pancakeswap-token","hedera-hashgraph","aave","quant-network","bitcoin-cash-abc-2","klay-token","near","the-graph","fantom","iota","neo","kusuma","bitcoin-cash-sv","leo-token","waves","celsius-degree-token","amp-token"]
    
    var mainApi = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
    
    var addApiData: [AddCoinViewController.JSONPrice] = []
    var searchApiData: [AddCoinViewController.JSONPrice] = []
    var allList = [String]()
    var searchList = [Int]()
    var searching = false
    
    struct JSONPrice: Codable {
        var name: String
        var image: String
        var id: String
    }

    
    func makeAPIList(_ localArr: inout [String]) -> String {
        if (localArr.count > 0 ){
            var temp = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
            for i in localArr {
                temp.self += "\(i),"
            }
            return temp
        } else { return "" }
    }
    
    func runAPI(url: String) {
        addApiData.removeAll()
        guard let url = URL(string: mainApi) else { return }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let dataResponse = data,
                  error == nil else {
                print(error?.localizedDescription ?? "Response Error")
                return }
            do {
                let decoder = JSONDecoder()
                let model = try decoder.decode([JSONPrice].self, from: dataResponse)
                print(model)
                self.addApiData = model
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch let parsingError {
                print("Error", parsingError)
            }
        }
        // Make API Call
        dataTask.resume()
        
    }
    
    func fetchImage(from string: String) -> UIImage? {
        guard let url = URL(string: string) else { return nil }
        
        var image: UIImage? = nil
        do {
            let data = try Data(contentsOf: url, options: [])
            image = UIImage(data: data)
        } catch { print(error.localizedDescription) }
        return image
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mainApi = makeAPIList(&addList)
        runAPI(url: mainApi)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        print("curList:",curList)


        // Do any additional setup after loading the view.
    }
    
    // How many cells to load
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return searchList.count
        }
        return addApiData.count
    }
    
    // Load data for each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "addCoinCell", for: indexPath) as! AddTableViewCell
        if (addApiData.count > 0) {
            if searching {
                cell.addCoinName.text = String(searchApiData[indexPath.row].name)
                let imgString = searchApiData[indexPath.row].image
                if let image = fetchImage(from: imgString) {
                    cell.addCoinImage.image = image
                }
            } else {
                cell.addCoinName.text = String(addApiData[indexPath.row].name)
                let imgString = addApiData[indexPath.row].image
                if let image = fetchImage(from: imgString) {
                    cell.addCoinImage.image = image
                }
            }
        }
        return cell
    }
    
    // Update WatchList
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if searching {
            if !curList.contains(searchApiData[indexPath.row].id) {
                curList.append(searchApiData[indexPath.row].id)
                print("curList NEW:", curList)
                let alertController:UIAlertController = UIAlertController(title: "Added Coin", message: "Successfully added \(searchApiData[indexPath.row].name)", preferredStyle: .alert)
                let alertAction:UIAlertAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
                alertController.addAction(alertAction)
                self.present(alertController, animated: true, completion: nil)
            }
        } else {
            if !curList.contains(addApiData[indexPath.row].id) {
                curList.append(addApiData[indexPath.row].id)
                print("curList NEW:", curList)
                let alertController:UIAlertController = UIAlertController(title: "Added Coin", message: "Successfully added \(addApiData[indexPath.row].name)", preferredStyle: .alert)
                let alertAction:UIAlertAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
                alertController.addAction(alertAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }

}

extension AddCoinViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchKey(key: searchText.capitalized, arr: addApiData)
        getKey(found: searchList, arr: addApiData)
        searching = true
        tableView.reloadData()
    }
    
    func searchKey(key: String, arr:Array<JSONPrice>) {
        searchList.removeAll()
        for i in 0..<(arr.count) {
            if arr[i].name.contains(key) {
                searchList.append(i)
            }
        }
    }
    
    func getKey(found: Array<Int>, arr:Array<JSONPrice>) {
        searchApiData.removeAll()
        for i in 0..<(found.count) {
            searchApiData.append(arr[found[i]])
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
        searchBar.text = ""
        tableView.reloadData()
    }
}
