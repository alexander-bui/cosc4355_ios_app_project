//
//  PersonalizedNewsTableViewController.swift
//  Crypto_App_Tracker
//
//  Created by student on 10/27/21.
//

import UIKit

struct PersonalizedNewsData: Codable {
    init () {
        data = [PersonalizedNews]()
    }
    let data: [PersonalizedNews]
}

struct PersonalizedNews: Codable {  //Identical to News + "tickers" array
    init() {
        news_url = ""       //Get a default
        image_url = ""      //Get a default
        title = "|News Headline|"
        text = "This is part of the news' text or description being shown..."
        source_name = "[Source]"
        date = "[Date]"
        topics = []
        sentiment = "[Sentiment]"
        type = ""
        tickers = []
    }
    let news_url: String
    let image_url: String
    let title: String
    let text: String        //1st part of news or description
    let source_name: String //Made By: source_name
    let date: String        //Format: "DayOfWeek, Day# Month Year HH(0-23):MM:SS -4000"
    let topics: [String]    //Can be empty, not of much use
    let sentiment: String   //"Neutral", "Positive", or "Negative"
    let type: String        //"Article" or "Video", may want option to see one or the other
    let tickers: [String]   //Array of Coin Abbreviations
}

class PersonalizedNewsTableViewController: UITableViewController {
    var newsInfo = [PersonalizedNews]()
    var selectedNews = PersonalizedNews()
    var coinInfo: [ViewController.JSONPrice] = []   //Just for images/logos of coins
    var coinList = ["bitcoin","ethereum"]           //Default, should become whatever the user selected, should also always have 1+ coins, should not allow user to enter this tab with an empty list
    var coinNameList = ["Bitcoin","Ethereum"]       //Default, get name versions of coinList for coinAbrevDict
    var coinAbrevDict = ["Bitcoin": "BTC",          //Dictionary of all coins and their abbreviations
                         "Ethereum": "ETH",
                         "Binance Coin":"BNB",
                         "Solana":"SOL",
                         "Cardano":"ADA",
                         "Polkadot":"DOT",
                         "Ripple": "XRP",           //XRP
                         "Dogecoin": "DOGE",
                         "Shiba Inu":"SHIB",
                         "Terra":"LUNA",
                         "Avalanche":"AVAX",
                         "Chainlink": "LINK",
                         "Litecoin": "LTC",
                         "Polygon": "MATIC",
                         "Uniswap": "UNI",
                         "Algorand": "ALGO",
                         "Bitcoin Cash": "BCH",
                         "Cosmos": "ATOM",
                         "Stellar": "XLM",          //Stellar Lumens
                         "VeChain": "VET",
                         "Axie Infinity": "AXS",
                         "Internet Computer": "ICP",
                         "Filecoin": "FIL",
                         "TRON": "TRX",
                         "FTX Token": "FTT",
                         "Theta": "THETA",          //Theta Network
                         "Ethereum Classic": "ETC",
                         "Fantom": "FTM",
                         "Crypto.com Coin": "CRO",
                         "Elrond": "EGLD",
                         "Hedera": "HBAR",          //Hedera Hashgraph
                         "OKB": "OKB",
                         "Near": "NEAR",            //Near Protocol
                         "Tezos": "XTZ",
                         "The Graph": "GRT",
                         "Monero": "XMR",
                         "EOS": "EOS",
                         "PancakeSwap": "CAKE",
                         "Klaytn": "KLAY",
                         "Aave": "AAVE",
                         "IOTA": "IOTA",
                         "Quant": "QNT",
                         "NEO": "NEO",
                         "LEO": "LEO",              //UNUS SED LEO  //Leo Token
                         "Bitcoin SV": "BSV",
                         "Amp": "AMP",
                         "Waves": "WAVES",
                         "Bitcoin Cash ABC": "BCHA",
                         "Celsius": "CEL"]          //Celsius Network

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if coinList.count > 0 {
            //print("_start_")
            coinInfo.removeAll()
            guard let url = URL(string: makeCoinAPIList(&coinList)) else { return }
            
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                guard let dataResponse = data,
                      error == nil else {
                    print(error?.localizedDescription ?? "Response Error")
                    return }
                do {
                    let decoder = JSONDecoder()
                    let model = try decoder.decode([ViewController.JSONPrice].self, from: dataResponse)
                    //print(model)
                    self.coinInfo = model
                    self.coinNameList.removeAll()
                    for c_info in model {
                        self.coinNameList.append(c_info.name)
                    }
                    //print("coinNameList = \(self.coinNameList)")
                    
                    var temp = "https://cryptonews-api.com/api/v1/?tickers="
                    var coinAbrevList: [String] = []
                    for var c in self.coinNameList {
                        //Special Cases:
                        if c == "XRP" {
                            c = "Ripple"
                        } else if c == "Theta Network" {
                            c = "Theta"
                        } else if c == "LEO Token" {
                            c = "LEO"
                        } else if c == "Celsius Network" {
                            c = "Celsius"
                        }
                        if let c_a = self.coinAbrevDict[c] {
                            coinAbrevList.append(c_a)
                        }
                    }
                    for c_a in coinAbrevList {
                        temp += "\(c_a),"
                    }
                    temp += "&items=50&sortby=rank&days=7&token=cpczksgr2munv2mmwhyfckriud19t6k01cxmb1so"
                    let newsUrl = URL(string: temp)
                    //print("newsUrl = \(temp); coinList = \(self.coinList)")
                    if newsUrl != nil {
                        self.parseData(url: newsUrl!)
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                } catch let parsingError {
                    print("Error", parsingError)
                }
            }.resume()
            //print("_end_")
        }
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsInfo.count
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 165
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let cell_CoinName = cell.viewWithTag(1) as! UILabel
        var tickersUnabrev: [String] = []
        for t in self.newsInfo[indexPath.row].tickers {
            if let t_ua = coinAbrevDict.first(where: { $0.value == t })?.key {
                tickersUnabrev.append(t_ua)
            }
        }
        if tickersUnabrev.count == 0 {
            cell_CoinName.text = "Unrecognized"  //Default
        } else {
            var i = 1
            var temp = ""
            for cName in tickersUnabrev {
                if i == 1 {
                    temp += cName
                    i += 1
                } else {
                    temp += ", \(cName)"
                    //May want to limit to only 3 (determine which 3 by which are most popular)
                }
            }
            cell_CoinName.text = temp
        }
        
        let cell_CoinImage = cell.viewWithTag(2) as! UIImageView
        if cell_CoinName.text! != "" && cell_CoinName.text! != "Unrecognized" {
            if cell_CoinName.text!.contains(",") {  //Multiple Coins
                cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")
            } else {                                //1 Coin, get its image
                var coinName = cell_CoinName.text!
                //Special Cases:
                if cell_CoinName.text! == "Ripple" {
                    coinName = "XRP"
                } else if cell_CoinName.text! == "Theta" {
                    coinName = "Theta Network"
                } else if cell_CoinName.text! == "LEO" {
                    coinName = "LEO Token"
                } else if cell_CoinName.text! == "Celsius" {
                    coinName = "Celsius Network"
                }
                //print(coinName)
                
                if let c_i = coinInfo.firstIndex(where: { $0.name == coinName }) {
                    //print("c_i = \(c_i); \(cell_CoinName.text!)")
                    if let url = URL(string: self.coinInfo[c_i].image) {
                        URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
                            if error != nil {
                                print(error!.localizedDescription)
                                return
                            }
                            DispatchQueue.main.async {
                                cell_CoinImage.image = UIImage(data: data!)
                            }
                        }).resume()
                    }
                } else {                            //Unrecognized
                    cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")
                }
            }
        } else {                                    //Unrecognized
            cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")
        }
        
//        if tickersUnabrev.count == 1 {
//            if let c_i = coinList.firstIndex(of: tickersUnabrev[0]) {
//                if c_i < coinInfo.count {
//                    if let url = URL(string: self.coinInfo[c_i].image) {
//                        URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
//                            if error != nil {
//                                print(error!.localizedDescription)
//                                return
//                            }
//                            DispatchQueue.main.async {
//                                cell_CoinImage.image = UIImage(data: data!)
//                            }
//                        }).resume()
//                    }
//                } else {
//                    cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")    //Index out of range ?
//                    print("> coinInfo.count = \(coinInfo.count); c_i = \(c_i); \(tickersUnabrev[0])")
//                }
//            } else {
//                cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")       //Default (Unrecognized), Shouldn't ever get here though
//                print("> ticker \"\(tickersUnabrev[0])\" unrecognized")
//            }
//        } else {
//            cell_CoinImage.image = #imageLiteral(resourceName: "GrayCircle")       //Default (Unrecognized or Multiple), could be a Filled Gray Circle or have a Plus in the center to indicate specifically Multiple
//        }
        
        let cell_NewsImage = cell.viewWithTag(3) as! UIImageView
        if let url = URL(string: self.newsInfo[indexPath.row].image_url) {
            URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error!.localizedDescription)
                    return
                }
                DispatchQueue.main.async {
                    cell_NewsImage.image = UIImage(data: data!)
                }
            }).resume()
        }
        
        let cell_Date_By = cell.viewWithTag(4) as! UILabel
        let newsDate = self.newsInfo[indexPath.row].date.components(separatedBy: " ")
        var newsDateShort = ""
        switch newsDate[2] {
        case "Jan":
            newsDateShort += "1/"
        case "Feb":
            newsDateShort += "2/"
        case "Mar":
            newsDateShort += "3/"
        case "Apr":
            newsDateShort += "4/"
        case "May":
            newsDateShort += "5/"
        case "Jun":
            newsDateShort += "6/"
        case "Jul":
            newsDateShort += "7/"
        case "Aug":
            newsDateShort += "8/"
        case "Sep":
            newsDateShort += "9/"
        case "Oct":
            newsDateShort += "10/"
        case "Nov":
            newsDateShort += "11/"
        case "Dec":
            newsDateShort += "12/"
        default:
            newsDateShort += "00/"
        }
        newsDateShort += "\(newsDate[1])/\(newsDate[3])"
        cell_Date_By.text = "\(newsDateShort) | By: \(self.newsInfo[indexPath.row].source_name)"
        
        let cell_Title = cell.viewWithTag(5) as! UILabel
        cell_Title.text = self.newsInfo[indexPath.row].title
        
        let cell_Text = cell.viewWithTag(6) as! UILabel
        cell_Text.text = self.newsInfo[indexPath.row].text
        
        let cell_Sentiment = cell.viewWithTag(7) as! UILabel
        cell_Sentiment.text = self.newsInfo[indexPath.row].sentiment
        var sentimentColor: UIColor
        switch self.newsInfo[indexPath.row].sentiment {
            case "Positive":
                sentimentColor = #colorLiteral(red: 0.2509803922, green: 0.7490196078, blue: 0.4666666667, alpha: 1)
            case "Negative":
                sentimentColor = #colorLiteral(red: 0.8980392157, green: 0.2745098039, blue: 0.1411764706, alpha: 1)
            default:
                sentimentColor = #colorLiteral(red: 0.3254901961, green: 0.3803921569, blue: 0.3843137255, alpha: 1)
        }
        cell_Sentiment.textColor = sentimentColor
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seg_news_page" {
            let mapView = segue.destination as! NewsViewController
            mapView.selectedNewsUrl = selectedNews.news_url
        }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedNews = newsInfo[indexPath.row]
        self.performSegue(withIdentifier: "seg_news_page", sender: self)
    }

    func parseData(url: URL) {
        let task = URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
            if let d = data {
                self.decodeData(downloadedData: d)
            }
            else if let e = error {
                print(e.localizedDescription)
            }
        })
        task.resume()
    }
    func decodeData(downloadedData: Data) {
        do {
            let content = try JSONDecoder().decode(PersonalizedNewsData.self, from: downloadedData)
            self.newsInfo = content.data
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        } catch {
            print("Error while decoding JSON data: \(downloadedData)")
        }
    }
    
    func makeCoinAPIList(_ localArr: inout [String]) -> String {
        if (localArr.count > 0 ) {
            var temp = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
            for i in localArr {
                temp.self += "\(i),"
            }
            return temp
        } else { return "" }
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
