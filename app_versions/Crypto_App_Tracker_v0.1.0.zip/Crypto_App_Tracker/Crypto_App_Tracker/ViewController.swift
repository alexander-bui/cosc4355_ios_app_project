//
//  ViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 9/23/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    
    var mainApi = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
    
    var coinList = ["bitcoin", "ethereum"]
    
    struct JSONPrice: Codable {
        var name: String
        var current_price: Float
        var price_change_percentage_24h: Float
    }
    
    func makeAPIList(_ localArr: inout [String]) {
        for i in localArr {
            mainApi.self += "\(i),"
        }
    }
    
    func runAPI(url: String) {
        guard let url = URL(string: mainApi) else { return }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let dataResponse = data,
                  error == nil else {
                print(error?.localizedDescription ?? "Response Error")
                return }
            do {
                let decoder = JSONDecoder()
                let model = try decoder.decode([JSONPrice].self, from: dataResponse)
                print(model)
//                self.coinName.text = String(model[0].name)
//                self.coinPrice.text = String(model[0].current_price)
//                self.coinChange.text = String(model[0].price_change_percentage_24h)
            } catch let parsingError {
                print("Error", parsingError)
            }
        }
        // Make API Call
        dataTask.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let nib = UINib(nibName: "CoinTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "CoinTableViewCell")
        tableView.delegate = self
        tableView.dataSource = self
        
        makeAPIList(&coinList)
        runAPI(url: mainApi)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return coinList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CoinTableViewCell", for: indexPath) as! CoinTableViewCell
        cell.coinLabel.text = coinList[indexPath.row]
        cell.coinImage.backgroundColor = .red
        return cell
    }


}

