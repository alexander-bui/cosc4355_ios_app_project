//
//  ViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 9/23/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    var mainApi = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
    
    var coinList = ["bitcoin","shiba-inu","crypto-com-chain"]
    
    var apiData: [ViewController.JSONPrice] = []
    
    struct JSONPrice: Codable {
        var name: String
        var current_price: Float
        var price_change_percentage_24h: Float
        var image: String
    }
    
    func makeAPIList(_ localArr: inout [String]) -> String {
        if (localArr.count > 0 ){
            var temp = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
            for i in localArr {
                temp.self += "\(i),"
            }
            return temp
        } else { return "" }
    }
    
    func runAPI(url: String) {
        apiData.removeAll()
        guard let url = URL(string: mainApi) else { return }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let dataResponse = data,
                  error == nil else {
                print(error?.localizedDescription ?? "Response Error")
                return }
            do {
                let decoder = JSONDecoder()
                let model = try decoder.decode([JSONPrice].self, from: dataResponse)
                print(model)
                self.apiData = model
                DispatchQueue.main.async {
                    self.tableView.refreshControl?.endRefreshing()
                    self.tableView.reloadData()
                }
            } catch let parsingError {
                print("Error", parsingError)
            }
        }
        // Make API Call
        dataTask.resume()
        
    }
    
    func fetchImage(from string: String) -> UIImage? {
        guard let url = URL(string: string) else { return nil }
        
        var image: UIImage? = nil
        do {
            let data = try Data(contentsOf: url, options: [])
            image = UIImage(data: data)
        } catch { print(error.localizedDescription) }
        return image
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        mainApi = makeAPIList(&coinList)
        runAPI(url: mainApi)
        
        let nib = UINib(nibName: "CoinTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "CoinTableViewCell")
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.refreshControl = UIRefreshControl()
        tableView.refreshControl?.addTarget(self, action: #selector(didPullToRefresh), for: .valueChanged)
    }
    
    // Refreshed View
    @objc func didPullToRefresh() {
        mainApi = makeAPIList(&coinList)
        runAPI(url: mainApi)
    }
    
    // How many cells to load
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return coinList.count
    }
    
    // Load data for each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CoinTableViewCell", for: indexPath) as! CoinTableViewCell
        if (apiData.count > 0) {
        cell.coinLabel.text = String(apiData[indexPath.row].name)
            cell.coinValue.text =  "$ \(String(apiData[indexPath.row].current_price))"
            let imgString = apiData[indexPath.row].image
                if let image = fetchImage(from: imgString) {
                    cell.coinImage.image = image
                }
        }
        return cell
    }
    
    // When selecting a cell
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(identifier: "DetailViewController") as? DetailViewController
        vc?.name = coinList[indexPath.row].capitalized
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    // Delete Coin from Main Price Table
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
            coinList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
            
        }
    }
    
    @IBAction func goToAdd(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToAdd" {
            let addSeg = segue.destination as! AddCoinViewController
            addSeg.curList = self.coinList
        }
    }
    
    @IBAction func backFromAddCoin(_ sender: UIStoryboardSegue) {
        if sender.source is AddCoinViewController {
            if let senderAddCoin = sender.source as? AddCoinViewController {
                self.coinList = senderAddCoin.curList
            }
            mainApi = makeAPIList(&coinList)
            runAPI(url: mainApi)
            tableView.reloadData()
        }
    }
    
}

