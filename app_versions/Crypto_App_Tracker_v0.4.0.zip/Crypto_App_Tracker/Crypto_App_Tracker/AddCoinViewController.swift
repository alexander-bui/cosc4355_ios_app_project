//
//  AddCoinViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 10/4/21.
//

import UIKit

class AddCoinViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    var curList = [""]
    
    var addList = ["bitcoin","ethereum","cardano","binancecoin","ripple","solana","dogecoin","polkadot","terra-luna","avalanche-2","uniswap","chainlink","litecoin","algorand","bitcoin-cash","shiba-inu","cosmos","internet-computer","matic-network","filecoin","axie-infinity","stellar","vechain","ethereum-classic","ftx-token","tron","tezos","theta-token","monero","elrond-erd-2","crypto-com-chain","okb","eos","pancakeswap-token","hedera-hashgraph","aave","quant-network","bitcoin-cash-abc-2","klay-token","near","the-graph","fantom","iota","neo","kusuma","bitcoin-cash-sv","leo-token","waves","celsius-degree-token","amp-token"]
    
    var mainApi = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
    
    var addApiData: [AddCoinViewController.JSONPrice] = []
    
    struct JSONPrice: Codable {
        var name: String
        var image: String
        var id: String
    }

    
    func makeAPIList(_ localArr: inout [String]) -> String {
        if (localArr.count > 0 ){
            var temp = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
            for i in localArr {
                temp.self += "\(i),"
            }
            return temp
        } else { return "" }
    }
    
    func runAPI(url: String) {
        addApiData.removeAll()
        guard let url = URL(string: mainApi) else { return }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let dataResponse = data,
                  error == nil else {
                print(error?.localizedDescription ?? "Response Error")
                return }
            do {
                let decoder = JSONDecoder()
                let model = try decoder.decode([JSONPrice].self, from: dataResponse)
                print(model)
                self.addApiData = model
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch let parsingError {
                print("Error", parsingError)
            }
        }
        // Make API Call
        dataTask.resume()
        
    }
    
    func fetchImage(from string: String) -> UIImage? {
        guard let url = URL(string: string) else { return nil }
        
        var image: UIImage? = nil
        do {
            let data = try Data(contentsOf: url, options: [])
            image = UIImage(data: data)
        } catch { print(error.localizedDescription) }
        return image
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mainApi = makeAPIList(&addList)
        runAPI(url: mainApi)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        print("curList:",curList)


        // Do any additional setup after loading the view.
    }
    
    // How many cells to load
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return addApiData.count
    }
    
    // Load data for each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "addCoinCell", for: indexPath) as! AddTableViewCell
        if (addApiData.count > 0) {
        cell.addCoinName.text = String(addApiData[indexPath.row].name)
        let imgString = addApiData[indexPath.row].image
            if let image = fetchImage(from: imgString) {
                cell.addCoinImage.image = image
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if !curList.contains(addApiData[indexPath.row].id) {
            curList.append(addApiData[indexPath.row].id)
            print("curList NEW:", curList)
        }
    }

}
