//
//  DetailViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 10/2/21.
//

import UIKit
import WebKit

class DetailViewController: UIViewController {

    @IBOutlet weak var coinName: UILabel!
    
    @IBOutlet weak var webEmbed: WKWebView!
    
    
    
    var name = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let html = """
<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div id="tradingview_27e65"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/BTCUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">BTCUSDT Chart</span></a> by TradingView</div>
  <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
  <script type="text/javascript">
  new TradingView.widget(
  {
  "autosize": true,
  "symbol": "BINANCE:BTCUSDT",
  "interval": "D",
  "timezone": "Etc/UTC",
  "theme": "light",
  "style": "1",
  "locale": "en",
  "toolbar_bg": "#f1f3f6",
  "enable_publishing": false,
  "container_id": "tradingview_27e65"
}
  );
  </script>
</div>
<!-- TradingView Widget END -->
"""
        self.webEmbed.loadHTMLString(html, baseURL: nil)
        
        coinName.text = "\(name)"
        // Do any additional setup after loading the view.
    }
    
    

}
