//
//  DetailViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 10/2/21.
//

import UIKit
import WebKit

class DetailViewController: UIViewController {

    @IBOutlet weak var coinName: UILabel!
    
    @IBOutlet weak var webEmbed: WKWebView!
    
    var name = ""
    var html = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.webEmbed.loadHTMLString(html, baseURL: nil)
        
        coinName.text = "\(name)"
        // Do any additional setup after loading the view.
    }
    
    

}
