//
//  CoinTableViewCell.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 10/2/21.
//

import UIKit



class CoinTableViewCell: UITableViewCell {
    
    @IBOutlet var coinLabel: UILabel!
    @IBOutlet var coinValue: UILabel!
    @IBOutlet var changeLabel: UILabel!
    @IBOutlet var changeValue: UILabel!
    @IBOutlet var coinImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
