//
//  ViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 9/23/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    var mainApi = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
    
    var coinList = ["bitcoin","ethereum"]
    
    var apiData: [ViewController.JSONPrice] = []
    
    struct JSONPrice: Codable {
        var name: String
        var current_price: Float
        var price_change_percentage_24h: Float
        var image: String
        var market_cap: Float
        var total_volume: Float
    }
    
    func makeAPIList(_ localArr: inout [String]) -> String {
        if (localArr.count > 0 ){
            var temp = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
            for i in localArr {
                temp.self += "\(i),"
            }
            return temp
        } else { return "" }
    }
    
    func runAPI(url: String) {
        apiData.removeAll()
        guard let url = URL(string: mainApi) else { return }
        
        let dataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let dataResponse = data,
                  error == nil else {
                print(error?.localizedDescription ?? "Response Error")
                return }
            do {
                let decoder = JSONDecoder()
                let model = try decoder.decode([JSONPrice].self, from: dataResponse)
                print(model)
                self.apiData = model
                DispatchQueue.main.async {
                    self.tableView.refreshControl?.endRefreshing()
                    self.tableView.reloadData()
                }
            } catch let parsingError {
                print("Error", parsingError)
            }
        }
        // Make API Call
        dataTask.resume()
        
    }
    
    func fetchImage(from string: String) -> UIImage? {
        guard let url = URL(string: string) else { return nil }
        
        var image: UIImage? = nil
        do {
            let data = try Data(contentsOf: url, options: [])
            image = UIImage(data: data)
        } catch { print(error.localizedDescription) }
        return image
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        mainApi = makeAPIList(&coinList)
        runAPI(url: mainApi)
        
        let nib = UINib(nibName: "CoinTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "CoinTableViewCell")
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.refreshControl = UIRefreshControl()
        tableView.refreshControl?.addTarget(self, action: #selector(didPullToRefresh), for: .valueChanged)
    }
    
    // Refreshed View
    @objc func didPullToRefresh() {
        mainApi = makeAPIList(&coinList)
        runAPI(url: mainApi)
    }
    
    // How many cells to load
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return coinList.count
    }
    
    // Load data for each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CoinTableViewCell", for: indexPath) as! CoinTableViewCell
        if (apiData.count > 0) {
        cell.coinLabel.text = String(apiData[indexPath.row].name)
            cell.changeLabel.text = "24H % Change:"
            cell.changeValue.text = String(apiData[indexPath.row].price_change_percentage_24h)
            cell.coinValue.text =  "$ \(String(apiData[indexPath.row].current_price))"
            let imgString = apiData[indexPath.row].image
                if let image = fetchImage(from: imgString) {
                    cell.coinImage.image = image
                }
        }
        return cell
    }
    
    // When selecting a cell
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(identifier: "DetailViewController") as? DetailViewController
        vc?.name = String(apiData[indexPath.row].name)
        vc?.html = htmlDict[String(coinList[indexPath.row])]!
        vc?.mcap = String(apiData[indexPath.row].market_cap)
        vc?.vol = String(apiData[indexPath.row].total_volume)
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    // Delete Coin from Main Price Table
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
            coinList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
            
        }
    }
    
    @IBAction func goToAdd(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToAdd" {
            let addSeg = segue.destination as! AddCoinViewController
            addSeg.curList = self.coinList
        }
    }
    
    @IBAction func backFromAddCoin(_ sender: UIStoryboardSegue) {
        if sender.source is AddCoinViewController {
            if let senderAddCoin = sender.source as? AddCoinViewController {
                self.coinList = senderAddCoin.curList
            }
            mainApi = makeAPIList(&coinList)
            runAPI(url: mainApi)
            tableView.reloadData()
        }
    }
    
    var htmlDict:[String:String] = ["bitcoin":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_3fe9e"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/BTCUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">BTCUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:BTCUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_3fe9e"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "ethereum":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_cb439"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/ETHUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">ETHUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:ETHUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_cb439"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "cardano":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_f087c"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/ADAUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">ADAUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:ADAUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_f087c"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "binancecoin":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_4dc0e"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/BNBUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">BNBUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:BNBUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_4dc0e"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    ""","ripple":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_8d6bd"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/XRPUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">XRPUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:XRPUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_8d6bd"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "solana":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_f9a82"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/SOLUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">SOLUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:SOLUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_f9a82"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "dogecoin":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_717eb"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/DOGEUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">DOGEUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:DOGEUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_717eb"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "polkadot":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_cfe59"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/DOTUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">DOTUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:DOTUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_cfe59"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "terra-luna":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_0f24a"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/LUNAUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">LUNAUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:LUNAUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_0f24a"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "avalanche-2":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_8f5cb"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/AVAX/" rel="noopener" target="_blank"><span class="blue-text">AVAX Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "AVAX",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_8f5cb"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "uniswap":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_df7b8"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/UNIUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">UNIUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:UNIUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_df7b8"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "chainlink":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_2841b"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/LINKUSD/?exchange=BITFINEX" rel="noopener" target="_blank"><span class="blue-text">LINKUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BITFINEX:LINKUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_2841b"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "litecoin":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_a3a82"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/LTCUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">LTCUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:LTCUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_a3a82"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "algorand":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_42878"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/ALGOUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">ALGOUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:ALGOUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_42878"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "bitcoin-cash":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_59ac8"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/BCHUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">BCHUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:BCHUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_59ac8"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "shiba-inu":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_f375d"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/SHIBUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">SHIBUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:SHIBUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_f375d"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "cosmos":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_b6b5d"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/ATOMUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">ATOMUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:ATOMUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_b6b5d"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "internet-computer":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_53666"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/ICPUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">ICPUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:ICPUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_53666"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "matic-network":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_657d1"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/MATICUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">MATICUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:MATICUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_657d1"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "filecoin":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_31be2"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/FILUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">FILUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:FILUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_31be2"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "axie-infinity":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_e1932"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/AXSUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">AXSUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:AXSUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_e1932"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "stellar":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_eb298"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/XLMUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">XLMUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:XLMUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_eb298"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "vechain":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_1a456"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/VETUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">VETUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:VETUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_1a456"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "ethereum-classic":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_ff28e"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/ETCUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">ETCUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:ETCUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_ff28e"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "ftx-token":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_f4724"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/FTTUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">FTTUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:FTTUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_f4724"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "tron":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_cd79b"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/TRXUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">TRXUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:TRXUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_cd79b"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "tezos":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_c5e27"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/XTZUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">XTZUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:XTZUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_c5e27"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "theta-token":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_3dbd4"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/THETAUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">THETAUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:THETAUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_3dbd4"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "monero":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_bf107"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/XMRUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">XMRUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:XMRUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_bf107"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "elrond-erd-2":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_bcf95"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/EGLDUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">EGLDUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:EGLDUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_bcf95"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "crypto-com-chain":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_8b0a2"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/CROUSDT/?exchange=OKEX" rel="noopener" target="_blank"><span class="blue-text">CROUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "OKEX:CROUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_8b0a2"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "okb":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_b84b5"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/OKBUSDT/?exchange=OKEX" rel="noopener" target="_blank"><span class="blue-text">OKBUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "OKEX:OKBUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_b84b5"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "eos":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_dd9df"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/EOSUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">EOSUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:EOSUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_dd9df"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "pancakeswap-token":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_e33fb"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/CAKEUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">CAKEUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:CAKEUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_e33fb"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "hedera-hashgraph":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_62653"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/HBARUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">HBARUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:HBARUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_62653"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "aave":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_a0bbb"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/AAVEUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">AAVEUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:AAVEUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_a0bbb"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "quant-network":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_cd1b4"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/QNTUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">QNTUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:QNTUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_cd1b4"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "bitcoin-cash-abc-2":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_d5990"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/BCHAUSDT/?exchange=KUCOIN" rel="noopener" target="_blank"><span class="blue-text">BCHAUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "KUCOIN:BCHAUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_d5990"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "klay-token":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_dd5bb"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/KLAYUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">KLAYUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:KLAYUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_dd5bb"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "near":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_c520d"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/NEARUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">NEARUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:NEARUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_c520d"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "the-graph":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_831bd"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/GRTUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">GRTUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:GRTUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_831bd"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "fantom":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_bef33"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/FTMUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">FTMUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:FTMUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_bef33"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "iota":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_39777"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/IOTAUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">IOTAUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:IOTAUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_39777"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "neo":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_14471"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/NEOUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">NEOUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:NEOUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_14471"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "kusuma":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_10296"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/KSMUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">KSMUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:KSMUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_10296"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "bitcoin-cash-sv":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_70879"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/BSVUSDT/?exchange=HUOBI" rel="noopener" target="_blank"><span class="blue-text">BSVUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "HUOBI:BSVUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_70879"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "leo-token":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_82cff"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/LEOUSD/?exchange=BITFINEX" rel="noopener" target="_blank"><span class="blue-text">LEOUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BITFINEX:LEOUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_82cff"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "waves":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_3e10e"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/WAVESUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">WAVESUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:WAVESUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_3e10e"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "celsius-degree-token":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_32292"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/CELOUSDT/?exchange=BINANCE" rel="noopener" target="_blank"><span class="blue-text">CELOUSDT Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "BINANCE:CELOUSDT",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_32292"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """,
    "amp-token":"""
    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div id="tradingview_e72bc"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/AMPUSD/?exchange=COINBASE" rel="noopener" target="_blank"><span class="blue-text">AMPUSD Chart</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
      <script type="text/javascript">
      new TradingView.widget(
      {
      "autosize": true,
      "symbol": "COINBASE:AMPUSD",
      "interval": "D",
      "timezone": "Etc/UTC",
      "theme": "light",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#f1f3f6",
      "enable_publishing": false,
      "container_id": "tradingview_e72bc"
    }
      );
      </script>
    </div>
    <!-- TradingView Widget END -->
    """
    ]
    
    
}

