//
//  AddTableViewCell.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 10/6/21.
//

import UIKit

class AddTableViewCell: UITableViewCell {

    @IBOutlet weak var addCoinImage: UIImageView!
    @IBOutlet weak var addCoinName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
