//
//  DetailViewController.swift
//  Crypto_App_Tracker
//
//  Created by Alex B on 10/2/21.
//

import UIKit
import WebKit

class DetailViewController: UIViewController {

    @IBOutlet weak var coinName: UILabel!
    @IBOutlet weak var webEmbed: WKWebView!
    @IBOutlet weak var marketCap: UILabel!
    @IBOutlet weak var volume24H: UILabel!
    
    var name = ""
    var html = ""
    var mcap = ""
    var vol = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.webEmbed.loadHTMLString(html, baseURL: nil)
        
        coinName.text = "\(name)"
        
        let numberFormat = NumberFormatter()
        numberFormat.numberStyle = .decimal
        let nmcap = numberFormat.string(from: NSDecimalNumber(string: mcap.self))
        let nvol = numberFormat.string(from: NSDecimalNumber(string: vol.self))
        
        marketCap.text = "Marketcap: $ \(String(describing: nmcap!))"
        
        volume24H.text = "Volume (24H): $ \(String(describing: nvol!))"
        // Do any additional setup after loading the view.
    }
    
    

}
